package com.niit.chatcollab.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.UserDAO;
import com.niit.model.User;

public class UserTest1 {

	public static void main (String ar[])
	{
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		User user=(User) context.getBean("user");
		UserDAO userDAO=(UserDAO) context.getBean("userDAO");
		user.setId("100");
		user.setName("ramya");
		user.setPassword("wqhdkjd");
		userDAO.saveOrUpdate(user);
		
	}
	
}
