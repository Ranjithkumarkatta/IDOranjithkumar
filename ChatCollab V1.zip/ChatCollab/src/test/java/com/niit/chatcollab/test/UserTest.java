package com.niit.chatcollab.test;


import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.UserDAO;
import com.niit.model.User;

public class UserTest {
	
	private User user;
	
	@Autowired
	private UserDAO userDAO;
	
	@Autowired
	private AnnotationConfigApplicationContext context;
	
	@Test
	public void test()
	{
	}
	
	@Before
	public void init()
	{
		user = new User();
		System.out.println(" I am Here in test");
		
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.chatcollab");
		context.refresh();
		System.out.println("After Refresh ");
		System.out.println("user="+user);
		user.setId("1");
		user.setName("RAM");
		user.setPassword("ramram");
		user.setAddress("Ayodhya");
		user.setEmail("ram@gmail.com");
		user.setMobile("9949098910");
		user.setReason("reason");
		
		userDAO=(UserDAO) context.getBean("userDAO");
		System.out.println( "after dao");
		userDAO.saveOrUpdate(user);			
	}
}