package com.niit.dao;

import java.util.List;

import com.niit.model.*;


public interface UserDAO {
	public List<User> list();
	public void  saveOrUpdate(User user);

}
