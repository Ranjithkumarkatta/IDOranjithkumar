package app.niit.services;

import java.util.List;

import app.niit.dao.UserDao;
import app.niit.model.User;

public interface UserService {
	
	
	
	public void setUserDAOImpl(UserDao userdao);
	
	public void saveOrUpdate(User user);
	
	public User getUserById(int userid);
	
	public List<User> list();
	
	public User getUserByname(String username);
	

}
