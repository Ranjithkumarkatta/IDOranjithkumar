package app.niit.services;

import java.util.*;
import  app.niit.dao.*;
import app.niit.model.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImpl implements UserService
{

	@Autowired
	private UserDao userdao;
	
	@Transactional
	public void setUserDAOImpl(UserDao userdao)
	{
		this.userdao=userdao;
	}

	@Transactional
	public void saveOrUpdate(User user) {
		userdao.SaveorUpdate(user);
		
	}

	@Transactional
	public User getUserById(int userid) {
		
		return userdao.getUserById(userid);
	}

	@Transactional
	public List<User> list() {
		
		return userdao.list();
	}

	@Transactional
	public User getUserByname(String username) {
		
		return userdao.getUserByname(username);
	}

	
}
