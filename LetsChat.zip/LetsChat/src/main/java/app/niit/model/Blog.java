package app.niit.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Blog")
public class Blog 
{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true)
	private int b_id;
	@NotEmpty(message = "blog id cannot be empty")
	private String b_title;
	@NotEmpty(message = "blog title cannot be empty")
	private String b_content;
	@NotEmpty(message = "blog content cannot be empty")
	private Date b_creation_date_time;
	private String b_username;
	@NotEmpty(message = "blog username cannot be empty")
	
	public int getB_id() {
		return b_id;
	}
	public void setB_id(int b_id) {
		this.b_id = b_id;
	}
	public String getB_title() {
		return b_title;
	}
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	public String getB_content() {
		return b_content;
	}
	public void setB_content(String b_content) {
		this.b_content = b_content;
	}
	public Date getB_creation_date_time() {
		return b_creation_date_time;
	}
	public void setB_creation_date_time(Date b_creation_date_time) {
		this.b_creation_date_time = b_creation_date_time;
	}
	public String getB_username() {
		return b_username;
	}
	public void setB_username(String b_username) {
		this.b_username = b_username;
	} 

}
