package app.niit.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="forum")
public class Forum 
{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true)
	private int f_id;
	@NotEmpty(message = "fourm id cannot be empty")
	private String f_tittle;
	@NotEmpty(message = "fourm title cannot be empty")
	private String f_content;
	@NotEmpty(message = "fourm content cannot be empty")
	private Date f_creation_date_time;
	private String f_category;
	@NotEmpty(message = "fourm category cannot be empty")
	private String f_usename;
	@NotEmpty(message = "fourm usename cannot be empty")

	public int getF_id() {
		return f_id;
	}
	public void setF_id(int f_id) {
		this.f_id = f_id;
	}
	public String getF_tittle() {
		return f_tittle;
	}
	public void setF_tittle(String f_tittle) {
		this.f_tittle = f_tittle;
	}
	public String getF_content() {
		return f_content;
	}
	public void setF_content(String f_content) {
		this.f_content = f_content;
	}
	public Date getF_creation_date_time() {
		return f_creation_date_time;
	}
	public void setF_creation_date_time(Date f_creation_date_time) {
		this.f_creation_date_time = f_creation_date_time;
	}
	public String getF_category() {
		return f_category;
	}
	public void setF_category(String f_category) {
		this.f_category = f_category;
	}
	public String getF_usename() {
		return f_usename;
	}
	public void setF_usename(String f_usename) {
		this.f_usename = f_usename;
	}	
}
