package app.niit.dao;

import java.util.List;

import app.niit.model.User;

public interface UserDao 
{
	public void SaveorUpdate(User user);
	public User getUserByname(String username);
	public User getUserById(int userid);
	public List<User>list();

}
